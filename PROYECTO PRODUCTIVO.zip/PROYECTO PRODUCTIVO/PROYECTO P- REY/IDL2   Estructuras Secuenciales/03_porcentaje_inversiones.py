# IDL 1 - Ejercicio 3: Porcentaje de inversión de tres personas
# Declaración de variables:
# inversion1, inversion2, inversion3, total, porcentajes: float
# 1. DECLARACION E INICIALIZACION DE VARIABLES
inversion1: float = 0.0
inversion2: float = 0.0
inversion3: float = 0.0
total: float = 0.0

inversion1 = float(input("Inversión de la persona 1: S/ "))
inversion2 = float(input("Inversión de la persona 2: S/ "))
inversion3 = float(input("Inversión de la persona 3: S/ "))
total = inversion1 + inversion2 + inversion3
if total <= 0:
    print("El total invertido debe ser mayor que cero.")
else:
    print(f"Persona 1: {inversion1 / total * 100:.2f}%")
    print(f"Persona 2: {inversion2 / total * 100:.2f}%")
    print(f"Persona 3: {inversion3 / total * 100:.2f}%")
