# IDL 1 - Ejercicio 7: Cobro de estacionamiento
# Declaración de variables:
# horas, minutos: int; cobro: float
# 1. DECLARACION E INICIALIZACION DE VARIABLES
horas: int = 0
minutos: int = 0
cobro: float = 0.0

horas = int(input("Ingrese las horas completas: "))
minutos = int(input("Ingrese los minutos restantes (0 a 59): "))
if horas < 0 or not 0 <= minutos <= 59:
    print("Ingrese un tiempo válido.")
else:
    cobro = horas * 5.00 + minutos * 0.10
    print(f"Total a pagar: S/ {cobro:.2f}")
