# IDL 1 - Ejercicio 2: Promedio de cuatro exámenes
# Declaración de variables:
# notas: list[float], numero: int, nota: float, promedio: float
# 1. DECLARACION E INICIALIZACION DE VARIABLES
notas: list[float] = []
numero: int = 0
nota: float = 0.0
promedio: float = 0.0

notas = []
for numero in range(1, 5):
    nota = float(input(f"Ingrese la nota del examen {numero}: "))
    notas.append(nota)
promedio = sum(notas) / 4
print(f"Promedio: {promedio:.2f}")
