# IDL 1 - Ejercicio 10: Denominaciones de un cajero automático
# Declaración de variables:
# retiro, denominacion, cantidad: int
# 1. DECLARACION E INICIALIZACION DE VARIABLES
retiro: int = 0
denominacion: int = 0
cantidad: int = 0

retiro = int(input("Ingrese el monto entero que desea retirar: S/ "))
if retiro < 0:
    print("El monto no puede ser negativo.")
else:
    for denominacion in [200, 100, 50, 20, 10, 5, 1]:
        cantidad = retiro // denominacion
        retiro = retiro % denominacion
        print(f"S/ {denominacion}: {cantidad}")
