# IDL 1 - Ejercicio 6: Tiempo aproximado vivido
# Declaración de variables:
# edad, meses, semanas, dias, horas: int
# 1. DECLARACION E INICIALIZACION DE VARIABLES
edad: int = 0
meses: int = 0
semanas: int = 0
dias: int = 0
horas: int = 0

edad = int(input("Ingrese la edad en años: "))
if edad < 0:
    print("La edad no puede ser negativa.")
else:
    meses = edad * 12
    semanas = edad * 52
    dias = edad * 365
    horas = dias * 24
    print(f"Meses aproximados: {meses}")
    print(f"Semanas aproximadas: {semanas}")
    print(f"Días aproximados: {dias}")
    print(f"Horas aproximadas: {horas}")
