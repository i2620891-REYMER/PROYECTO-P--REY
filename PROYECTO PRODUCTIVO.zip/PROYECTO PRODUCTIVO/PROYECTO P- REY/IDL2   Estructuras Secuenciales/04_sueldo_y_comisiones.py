# IDL 1 - Ejercicio 4: Sueldo base y comisión por tres ventas
# Declaración de variables:
# sueldo_base, venta, total_ventas, comision, total_mensual: float
# ventas: list[float], numero: int
# 1. DECLARACION E INICIALIZACION DE VARIABLES
sueldo_base: float = 0.0
venta: float = 0.0
total_ventas: float = 0.0
comision: float = 0.0
total_mensual: float = 0.0
ventas: list[float] = []
numero: int = 0

sueldo_base = float(input("Ingrese el sueldo base: S/ "))
ventas = []
for numero in range(1, 4):
    venta = float(input(f"Ingrese el importe de la venta {numero}: S/ "))
    ventas.append(venta)
total_ventas = sum(ventas)
comision = total_ventas * 0.25
total_mensual = sueldo_base + comision
print(f"Total de ventas: S/ {total_ventas:.2f}")
print(f"Comisión (25%): S/ {comision:.2f}")
print(f"Total mensual a recibir: S/ {total_mensual:.2f}")
