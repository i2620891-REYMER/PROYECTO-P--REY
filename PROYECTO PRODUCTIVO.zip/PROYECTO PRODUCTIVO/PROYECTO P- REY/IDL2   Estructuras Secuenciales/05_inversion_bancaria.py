# IDL 1 - Ejercicio 5: Ganancia de inversión bancaria
# Declaración de variables:
# capital, tasa_mensual, ganancia, monto_final: float; meses: int
# Supuesto: interés simple, ya que el enunciado no especifica capitalización.
# 1. DECLARACION E INICIALIZACION DE VARIABLES
capital: float = 0.0
tasa_mensual: float = 0.02
meses: int = 12
ganancia: float = 0.0
monto_final: float = 0.0

capital = float(input("Ingrese el capital invertido: S/ "))
tasa_mensual = 0.02
meses = 12
ganancia = capital * tasa_mensual * meses
monto_final = capital + ganancia
print(f"Ganancia después de un año: S/ {ganancia:.2f}")
print(f"Monto final: S/ {monto_final:.2f}")
