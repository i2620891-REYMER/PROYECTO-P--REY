# IDL 1 - Ejercicio 8: Área del terreno según la figura A
# Declaración de variables:
# lado_paralelo_A, distancia_B, lado_paralelo_C, area: float
# La figura A del documento es un trapecio.
# A y C son los lados paralelos; B es la distancia perpendicular entre ellos.
# 1. DECLARACION E INICIALIZACION DE VARIABLES
lado_paralelo_A: float = 0.0
distancia_B: float = 0.0
lado_paralelo_C: float = 0.0
area: float = 0.0

lado_paralelo_A = float(input("Ingrese la longitud del lado paralelo A: "))
distancia_B = float(input("Ingrese la distancia perpendicular B: "))
lado_paralelo_C = float(input("Ingrese la longitud del lado paralelo C: "))
if lado_paralelo_A <= 0 or distancia_B <= 0 or lado_paralelo_C <= 0:
    print("Las medidas deben ser mayores que cero.")
else:
    area = ((lado_paralelo_A + lado_paralelo_C) / 2) * distancia_B
    print(f"Área del terreno: {area:.2f} unidades cuadradas")
