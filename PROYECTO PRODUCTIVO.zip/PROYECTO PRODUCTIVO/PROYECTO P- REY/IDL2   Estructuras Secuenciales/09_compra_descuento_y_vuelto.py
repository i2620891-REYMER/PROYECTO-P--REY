# IDL 1 - Ejercicio 9: Compra con descuento y cálculo de vuelto
# Declaración de variables:
# monto, porcentaje, efectivo, descuento, total_pagar, vuelto: float
# 1. DECLARACION E INICIALIZACION DE VARIABLES
monto: float = 0.0
porcentaje: float = 0.0
efectivo: float = 0.0
descuento: float = 0.0
total_pagar: float = 0.0
vuelto: float = 0.0

monto = float(input("Ingrese el monto base de la compra: S/ "))
porcentaje = float(input("Ingrese el porcentaje de descuento: "))
efectivo = float(input("Ingrese el dinero entregado: S/ "))
if monto < 0 or not 0 <= porcentaje <= 100 or efectivo < 0:
    print("Verifique los datos ingresados.")
else:
    descuento = monto * porcentaje / 100
    total_pagar = monto - descuento
    vuelto = efectivo - total_pagar
    print(f"Descuento: S/ {descuento:.2f}")
    print(f"Total a pagar: S/ {total_pagar:.2f}")
    if vuelto >= 0:
        print(f"Vuelto: S/ {vuelto:.2f}")
    else:
        print(f"Dinero faltante: S/ {abs(vuelto):.2f}")
