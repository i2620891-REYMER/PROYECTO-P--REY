# IDL 1 - Ejercicio 1: Velocidad final de un automóvil
# Declaración de variables:
# velocidad_inicial_kmh: float, aceleracion: float, tiempo: int
# velocidad_inicial_ms: float, velocidad_final_ms: float, velocidad_final_kmh: float
# Datos: vi = 0 km/h, a = 0.8 m/s², t = 30 s
# 1. DECLARACION E INICIALIZACION DE VARIABLES
velocidad_inicial_kmh: float = 0.0
aceleracion: float = 0.0
tiempo: int = 0
velocidad_inicial_ms: float = 0.0
velocidad_final_ms: float = 0.0
velocidad_final_kmh: float = 0.0

velocidad_inicial_kmh = 0.0
aceleracion = 0.8
tiempo = 30
velocidad_inicial_ms = velocidad_inicial_kmh / 3.6
velocidad_final_ms = velocidad_inicial_ms + aceleracion * tiempo
velocidad_final_kmh = velocidad_final_ms * 3.6
print(f"Velocidad final: {velocidad_final_ms:.2f} m/s")
print(f"Velocidad final: {velocidad_final_kmh:.2f} km/h")
