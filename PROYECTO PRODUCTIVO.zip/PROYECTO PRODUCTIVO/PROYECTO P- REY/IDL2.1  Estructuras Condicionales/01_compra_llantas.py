# IDL 2 - Ejercicio 1: Compra de llantas
# Declaración de variables:
# cantidad: int; precio_unitario, total: float
# 1. DECLARACION E INICIALIZACION DE VARIABLES
cantidad: int = 0
precio_unitario: float = 0.0
total: float = 0.0

cantidad = int(input("Ingrese la cantidad de llantas: "))
if cantidad <= 0:
    print("La cantidad debe ser mayor que cero.")
else:
    precio_unitario = 150 if cantidad < 5 else 120
    total = cantidad * precio_unitario
    print(f"Precio por llanta: S/ {precio_unitario:.2f}")
    print(f"Total a pagar: S/ {total:.2f}")
