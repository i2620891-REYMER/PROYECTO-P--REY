# IDL 2 - Ejercicio 7: Pago de llamada telefónica
# Declaración de variables:
# minutos: int; dia, turno_nocturno: str
# costo_base, tasa, impuesto: float
# 1. DECLARACION E INICIALIZACION DE VARIABLES
minutos: int = 0
dia: str = ""
turno_nocturno: str = ""
costo_base: float = 0.0
tasa: float = 0.0
impuesto: float = 0.0

minutos = int(input("Ingrese la duración de la llamada en minutos: "))
dia = input("Ingrese el día de la llamada: ").strip().lower()
turno_nocturno = input("¿Es turno nocturno? (si/no): ").strip().lower()
if minutos <= 0:
    print("La duración debe ser mayor que cero.")
else:
    costo_base = min(minutos, 5) * 1.00
    if minutos > 5:
        costo_base += min(minutos - 5, 3) * 0.80
    if minutos > 8:
        costo_base += min(minutos - 8, 2) * 0.70
    if minutos > 10:
        costo_base += (minutos - 10) * 0.50
    tasa = 0.05 if dia == "domingo" and turno_nocturno == "si" else (0.03 if dia == "domingo" else 0)
    impuesto = costo_base * tasa
    print(f"Costo base: S/ {costo_base:.2f}")
    print(f"Impuesto: S/ {impuesto:.2f}")
    print(f"Total a pagar: S/ {costo_base + impuesto:.2f}")
