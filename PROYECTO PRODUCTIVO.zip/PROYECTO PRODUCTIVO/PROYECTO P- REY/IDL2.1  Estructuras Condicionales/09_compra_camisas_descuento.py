# IDL 2 - Ejercicio 9: Compra de camisas con descuento
# Declaración de variables:
# cantidad: int; precio_unitario, subtotal, tasa_descuento, descuento, total: float
# 1. DECLARACION E INICIALIZACION DE VARIABLES
cantidad: int = 0
precio_unitario: float = 0.0
subtotal: float = 0.0
tasa_descuento: float = 0.0
descuento: float = 0.0
total: float = 0.0

cantidad = int(input("Ingrese la cantidad de camisas: "))
precio_unitario = float(input("Ingrese el precio unitario de cada camisa: S/ "))
if cantidad <= 0 or precio_unitario < 0:
    print("Ingrese una cantidad positiva y un precio no negativo.")
else:
    subtotal = cantidad * precio_unitario
    if 1 <= cantidad <= 4:
        tasa_descuento = 0.125
    elif 5 <= cantidad <= 8:
        tasa_descuento = 0.20
    else:
        tasa_descuento = 0.315
    descuento = subtotal * tasa_descuento
    total = subtotal - descuento
    print(f"Compra sin descuento: S/ {subtotal:.2f}")
    print(f"Descuento: S/ {descuento:.2f}")
    print(f"Compra con descuento: S/ {total:.2f}")
