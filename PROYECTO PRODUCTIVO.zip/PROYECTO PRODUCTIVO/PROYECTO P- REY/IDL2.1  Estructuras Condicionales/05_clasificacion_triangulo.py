# IDL 2 - Ejercicio 5: Clasificación de un triángulo
# Declaración de variables:
# lado_a, lado_b, lado_c, semiperimetro, area: float
# iguales: tuple[float, float]; math: módulo
import math
# 1. DECLARACION E INICIALIZACION DE VARIABLES
lado_a: float = 0.0
lado_b: float = 0.0
lado_c: float = 0.0
semiperimetro: float = 0.0
area: float = 0.0
iguales: tuple[float, float] = (0.0, 0.0)

lado_a = float(input("Ingrese el lado a: "))
lado_b = float(input("Ingrese el lado b: "))
lado_c = float(input("Ingrese el lado c: "))
if min(lado_a, lado_b, lado_c) <= 0 or lado_a + lado_b <= lado_c or lado_a + lado_c <= lado_b or lado_b + lado_c <= lado_a:
    print("Las medidas no forman un triángulo.")
elif lado_a == lado_b == lado_c:
    print("Triángulo equilátero.")
    print(f"Perímetro: {lado_a + lado_b + lado_c:.2f}")
elif lado_a == lado_b or lado_a == lado_c or lado_b == lado_c:
    if lado_a == lado_b:
        iguales = (lado_a, lado_b)
    elif lado_a == lado_c:
        iguales = (lado_a, lado_c)
    else:
        iguales = (lado_b, lado_c)
    print("Triángulo isósceles.")
    print(f"Lados iguales: {iguales[0]} y {iguales[1]}")
else:
    semiperimetro = (lado_a + lado_b + lado_c) / 2
    area = math.sqrt(semiperimetro * (semiperimetro-lado_a) * (semiperimetro-lado_b) * (semiperimetro-lado_c))
    print("Triángulo escaleno.")
    print(f"Área: {area:.2f}")
