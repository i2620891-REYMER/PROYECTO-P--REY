# IDL 2 - Ejercicio 2: Determinar el menor y el mayor
# Declaración de variables:
# numero1, numero2, numero3: float
# 1. DECLARACION E INICIALIZACION DE VARIABLES
numero1: float = 0.0
numero2: float = 0.0
numero3: float = 0.0

numero1 = float(input("Ingrese el primer número: "))
numero2 = float(input("Ingrese el segundo número: "))
numero3 = float(input("Ingrese el tercer número: "))
print(f"El menor es: {min(numero1, numero2, numero3)}")
print(f"El mayor es: {max(numero1, numero2, numero3)}")
