# IDL 2 - Ejercicio 3: Determinar si corresponde tributar
# Declaración de variables:
# edad: int; ingreso, impuesto: float
# 1. DECLARACION E INICIALIZACION DE VARIABLES
edad: int = 0
ingreso: float = 0.0
impuesto: float = 0.0

edad = int(input("Ingrese su edad: "))
ingreso = float(input("Ingrese sus ingresos mensuales: S/ "))
if edad > 18 and ingreso >= 3000:
    impuesto = ingreso * 0.05
    print("El usuario debe tributar.")
    print(f"Monto a tributar: S/ {impuesto:.2f}")
else:
    print("El usuario no debe tributar.")
