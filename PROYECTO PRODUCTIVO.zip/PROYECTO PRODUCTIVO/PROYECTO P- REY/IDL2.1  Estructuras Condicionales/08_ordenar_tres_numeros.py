# IDL 2 - Ejercicio 8: Ordenar tres números diferentes
# Declaración de variables:
# numero1, numero2, numero3: int; orden: str; numeros: list[int]
# 1. DECLARACION E INICIALIZACION DE VARIABLES
numero1: int = 0
numero2: int = 0
numero3: int = 0
orden: str = ""
numeros: list[int] = []

numero1 = int(input("Ingrese el primer número entero: "))
numero2 = int(input("Ingrese el segundo número entero: "))
numero3 = int(input("Ingrese el tercer número entero: "))
if len({numero1, numero2, numero3}) != 3:
    print("Los tres números deben ser diferentes.")
else:
    orden = input("¿Orden ascendente o descendente?: ").strip().lower()
    numeros = [numero1, numero2, numero3]
    if orden == "ascendente":
        numeros.sort()
        print("Orden ascendente:", numeros)
    elif orden == "descendente":
        numeros.sort(reverse=True)
        print("Orden descendente:", numeros)
    else:
        print("Opción no válida. Escriba ascendente o descendente.")
