# IDL 2 - Ejercicio 4: Cálculo de colegiatura
# Declaración de variables:
# materias: int; promedio, colegiatura, descuento, total: float
# 1. DECLARACION E INICIALIZACION DE VARIABLES
materias: int = 0
promedio: float = 0.0
colegiatura: float = 0.0
descuento: float = 0.0
total: float = 0.0

materias = int(input("Ingrese el número de materias: "))
promedio = float(input("Ingrese el promedio del último periodo: "))
if materias <= 0:
    print("La cantidad de materias debe ser positiva.")
else:
    colegiatura = materias * 100
    # Interpretación: 50% de descuento sobre el costo de la mitad de las materias.
    descuento = (colegiatura / 2) * 0.50 if promedio >= 18 else 0
    total = colegiatura - descuento
    print(f"Colegiatura sin descuento: S/ {colegiatura:.2f}")
    print(f"Descuento: S/ {descuento:.2f}")
    print(f"Total a pagar: S/ {total:.2f}")
