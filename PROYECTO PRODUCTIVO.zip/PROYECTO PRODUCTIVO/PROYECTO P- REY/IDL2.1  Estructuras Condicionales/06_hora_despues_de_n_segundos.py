# IDL 2 - Ejercicio 6: Hora después de N segundos
# Declaración de variables:
# hora, minuto, segundo, n, total_segundos: int
# nueva_hora, nuevo_minuto, nuevo_segundo: int
# 1. DECLARACION E INICIALIZACION DE VARIABLES
hora: int = 0
minuto: int = 0
segundo: int = 0
n: int = 0
total_segundos: int = 0
nueva_hora: int = 0
nuevo_minuto: int = 0
nuevo_segundo: int = 0

hora = int(input("Ingrese la hora (0-23): "))
minuto = int(input("Ingrese los minutos (0-59): "))
segundo = int(input("Ingrese los segundos (0-59): "))
n = int(input("Ingrese los segundos que se añadirán: "))
if not (0 <= hora <= 23 and 0 <= minuto <= 59 and 0 <= segundo <= 59 and n >= 0):
    print("La hora o los segundos ingresados no son válidos.")
else:
    total_segundos = (hora * 3600 + minuto * 60 + segundo + n) % 86400
    nueva_hora = total_segundos // 3600
    nuevo_minuto = (total_segundos % 3600) // 60
    nuevo_segundo = total_segundos % 60
    print(f"Hora resultante: {nueva_hora:02d}:{nuevo_minuto:02d}:{nuevo_segundo:02d}")
