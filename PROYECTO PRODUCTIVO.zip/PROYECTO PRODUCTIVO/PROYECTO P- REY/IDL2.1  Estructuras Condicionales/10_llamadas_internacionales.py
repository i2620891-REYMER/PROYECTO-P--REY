# IDL 2 - Ejercicio 10: Costo de llamadas internacionales
# Declaración de variables:
# zonas: dict[int, tuple[str, float]]; codigo: int; minutos, costo_minuto, total: float
# nombre_zona: str
# 1. DECLARACION E INICIALIZACION DE VARIABLES
zonas: dict[int, tuple[str, float]] = {}
codigo: int = 0
minutos: float = 0.0
costo_minuto: float = 0.0
total: float = 0.0
nombre_zona: str = ""

zonas = {
    10: ("América del norte", 2.2),
    12: ("América del centro", 2.5),
    20: ("América del sur", 1.2),
    22: ("Asia", 3.5),
    30: ("Europa", 3.0),
    32: ("África", 3.2)
}
codigo = int(input("Ingrese el código de la zona: "))
minutos = float(input("Ingrese los minutos hablados: "))
if minutos < 0:
    print("Los minutos no pueden ser negativos.")
elif codigo not in zonas:
    print("El código de zona no existe.")
else:
    nombre_zona, costo_minuto = zonas[codigo]
    total = minutos * costo_minuto
    print(f"Zona geográfica: {nombre_zona}")
    print(f"Costo por minuto: S/ {costo_minuto:.2f}")
    print(f"Costo total: S/ {total:.2f}")
