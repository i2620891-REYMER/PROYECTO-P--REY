# MENU PRINCIPAL - IDL 1 E IDL 2
# Permite seleccionar y ejecutar cualquiera de los 20 ejercicios desde un solo archivo.
import subprocess
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent

ejercicios = {
    "1": ("IDL 1 - Estructuras secuenciales", [
        "01_velocidad_final.py", "02_promedio_cuatro_examenes.py",
        "03_porcentaje_inversiones.py", "04_sueldo_y_comisiones.py",
        "05_inversion_bancaria.py", "06_tiempo_de_vida.py",
        "07_cobro_estacionamiento.py", "08_area_terreno_trapecio.py",
        "09_compra_descuento_y_vuelto.py", "10_denominaciones_cajero.py"
    ]),
    "2": ("IDL 2 - Estructuras condicionales", [
        "01_compra_llantas.py", "02_mayor_y_menor_tres_numeros.py",
        "03_calculo_impuesto.py", "04_colegiatura_descuento.py",
        "05_clasificacion_triangulo.py", "06_hora_despues_de_n_segundos.py",
        "07_pago_llamada.py", "08_ordenar_tres_numeros.py",
        "09_compra_camisas_descuento.py", "10_llamadas_internacionales.py"
    ])
}

while True:
    print("\n===== PROGRAMAS IDL 1 E IDL 2 =====")
    print("1. Ver ejercicios IDL 1")
    print("2. Ver ejercicios IDL 2")
    print("0. Salir")
    opcion = input("Seleccione una opción: ").strip()

    if opcion == "0":
        print("Fin del programa.")
        break
    if opcion not in ejercicios:
        print("Opción no válida.")
        continue

    titulo, archivos = ejercicios[opcion]
    carpeta = "IDL1_Estructuras_Secuenciales" if opcion == "1" else "IDL2_Estructuras_Condicionales"
    print(f"\n{titulo}")
    for i, archivo in enumerate(archivos, start=1):
        print(f"{i}. {archivo}")
    seleccion = input("Ingrese el número del ejercicio que desea ejecutar (1-10): ").strip()
    if not seleccion.isdigit() or not 1 <= int(seleccion) <= 10:
        print("Selección no válida.")
        continue

    archivo = BASE / carpeta / archivos[int(seleccion) - 1]
    print(f"\nEjecutando: {archivo.name}\n")
    subprocess.run([sys.executable, str(archivo)], cwd=str(archivo.parent))
    input("\nPresione ENTER para volver al menú...")
